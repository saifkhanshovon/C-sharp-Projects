﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.MobileManagement.Entity
{
    public class Product : IProduct
    {
        /*string mobile_Brand;
        string mobile_Model;
        string mobile_Quantity;
        string mobile_Details;
        int mobile_UnitPrice;
        */
        string category;
        string brand;
        string model;
        int quantity;
        int unitPrice;
        string details;


        public Product(string category, string brand, string model, int quantity, int unitPrice, string details)
        {
            this.category = category;
            this.brand = brand;
            this.model = model;
            this.quantity = quantity;
            this.unitPrice = unitPrice;
            this.details = details;

        }

        public string Category
        {
            set { this.category = value; }
            get { return category; }
        }

        public string Brand
        {
            set { this.brand = value; }
            get { return brand; }
        }

        public string Model
        {
            set { this.model = value; }
            get { return model; }
        }
        public int Quantity
        {
            set { this.quantity = value; }
            get { return quantity; }
        }

        public int UnitPrice
        {
            set { this.unitPrice = value; }
            get { return unitPrice; }
        }

        public string Details
        {
            set { this.details = value; }
            get { return details; }
        }

    }
}
