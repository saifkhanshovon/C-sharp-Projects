﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.MobileManagement.Entity
{
   public class Customer : ICustomer
    {
        string customer_phone;
        string customer_name;
        string customer_email;
        string customer_Address;
        string customer_sex;

        public Customer(string customer_phone, string customer_name, string customer_email, string customer_Address, string customer_sex)
        {
            this.customer_phone = customer_phone;
            this.customer_name = customer_name;
            this.customer_email = customer_email;
            this.customer_Address = customer_Address;
            this.customer_sex = customer_sex;
        }

        public string Name
        {
            set { this.customer_name = value; }
            get { return customer_name; }
        }

        public string Phone
        {
            set { this.customer_phone = value; }
            get { return customer_phone; }
        }

        public string Email
        {
            set { this.customer_email = value; }
            get { return customer_email; }
        }

        public string Customer_Address
        {
            set { this.customer_Address = value; }
            get { return customer_Address; }
        }

        public string Customer_Sex
        {
            set { this.customer_sex = value; }
            get { return customer_sex; }
        }




    }
}
