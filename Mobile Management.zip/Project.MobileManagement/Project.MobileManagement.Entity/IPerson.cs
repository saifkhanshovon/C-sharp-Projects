﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.MobileManagement.Entity
{
    interface IPerson
    {
        string Name
        {
            set;
            get;
        }

        string Phone
        {
            set;
            get;
        }

        string Email
        {
            set;
            get;
        }

    }
}
