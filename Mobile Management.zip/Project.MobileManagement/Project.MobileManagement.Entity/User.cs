﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.MobileManagement.Entity
{
    public class User : IUser
    {

        string user_name;
        string user_password;
        string user_type;
        string user_email;
        string user_phone;

        public User(string user_name, string user_password, string user_type, string user_email, string user_phone)
        {

            this.user_name = user_name;
            this.user_password = user_password;
            this.user_type = user_type;
            this.user_email = user_email;
            this.user_phone = user_phone;

        }


        public string Name
        {
            set { this.user_name = value; }
            get { return user_name; }
        }
        public string User_Password
        {
            set { this.user_password = value; }
            get { return user_password; }
        }
        public string Email
        {
            set { this.user_email = value; }
            get { return user_email; }
        }

        public string Phone
        {
            set { this.user_phone = value; }
            get { return user_phone; }
        }

        public string User_Type
        {
            set { this.user_type = value; }
            get { return user_type; }
        }
    }
}
