﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.MobileManagement.Entity
{
    public class Sale : Product
    {
        /* string customer_Name;
         string customer_phone;
         string customer_Email;
         int total_Bill;
         DateTime date;
         string category;
         string brand;
         string model;
         int quantity;
         int unitPrice;
         string details;
         DateTime bill_date;


         public Sale(string customer_Name, string customer_phone,string customer_Email, string category, string brand, string model, int quantity, int unitPrice, string details,int total_Bill,DateTime date)
         {
             this.Customer_Name = customer_Name;
             this.Customer_phone = customer_phone;
             this.Customer_Email = customer_Email;
             this.Total_Bill = total_Bill;
             this.category = category;
             this.brand = brand;
             this.model = model;
             this.quantity = quantity;
             this.unitPrice = unitPrice;
             this.details = details;
             this.Bill_date = date;
         }
         public string Customer_phone
         {
             get
             {
                 return customer_phone;
             }

             set
             {
                 customer_phone = value;
             }
         }

         public string Customer_Email
         {
             get
             {
                 return customer_Email;
             }

             set
             {
                 customer_Email = value;
             }
         }

         public string Customer_Name
         {
             get
             {
                 return customer_Name;
             }

             set
             {
                 customer_Name = value;
             }
         }

         public int Total_Bill
         {
             get
             {
                 return total_Bill;
             }

             set
             {
                 total_Bill = value;
             }
         }


         public string Category
         {
             set { this.category = value; }
             get { return category; }
         }

         public string Brand
         {
             set { this.brand = value; }
             get { return brand; }
         }

         public string Model
         {
             set { this.model = value; }
             get { return model; }
         }
         public int Quantity
         {
             set { this.quantity = value; }
             get { return quantity; }
         }

         public int UnitPrice
         {
             set { this.unitPrice = value; }
             get { return unitPrice; }
         }

         public string Details
         {
             set { this.details = value; }
             get { return details; }
         }

         public DateTime Bill_date
         {
             get
             {
                 return bill_date;
             }

             set
             {
                 bill_date = value;
             }
         }
          */

        string customer_Name;
        string customer_phone;
        string customer_Email;
        DateTime bill_date;
        int total_Bill;


        public Sale(string customer_Name, string customer_phone, string customer_Email, string category, string brand, string model, int quantity, int unitPrice, string details, int total_Bill, DateTime date) : base(category, brand, model, quantity, unitPrice, details)
        {
            this.customer_Name = customer_Name;
            this.customer_phone = customer_phone;
            this.customer_Email = customer_Email;
            this.bill_date = date;
            this.total_Bill = total_Bill;
        }

        public string Customer_phone
        {
            get
            {
                return customer_phone;
            }

            set
            {
                customer_phone = value;
            }
        }

        public string Customer_Email
        {
            get
            {
                return customer_Email;
            }

            set
            {
                customer_Email = value;
            }
        }

        public string Customer_Name
        {
            get
            {
                return customer_Name;
            }

            set
            {
                customer_Name = value;
            }
        }
        public int Total_Bill
        {
            get
            {
                return total_Bill;
            }

            set
            {
                total_Bill = value;
            }
        }
        public DateTime Bill_date
        {
            get
            {
                return bill_date;
            }

            set
            {
                bill_date = value;
            }
        }



    }


}
