﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.MobileManagement.Entity
{
    interface IUser : IPerson
    {

        string User_Password
        {
            set;
            get;
        }
        string User_Type
        {
            set;
            get;
        }

    }
}
