﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.MobileManagement.Entity
{
    interface IProduct
    {
        string Category
        {
            set;
            get;
        }

        string Brand
        {
            set;
            get;
        }

        string Model
        {
            set;
            get;
        }
        int Quantity
        {
            set;
            get;
        }

        string Details
        {
            set;
            get;
        }

        int UnitPrice
        {
            set;
            get;
        }

    }
}
