﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.MobileManagement.Entity
{
    interface ICustomer : IPerson
    {
        string Customer_Address
        {
            set;
            get;
        }

        string Customer_Sex
        {
            set;
            get;
        }




    }
}
