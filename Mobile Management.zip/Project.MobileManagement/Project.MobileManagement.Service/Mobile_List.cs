﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Project.MobileManagement.Data;
using Project.MobileManagement.Entity;


namespace Project.MobileManagement.Service
{
    public class Mobile_List
    {
        public List<Product> Product_View()
        {
            //SqlCommand cmd = new SqlCommand("SELECT id, name, email FROM person", connection);
            SqlDataReader reader = DataAccess.GetData("SELECT * FROM Product");
            List<Product> productList = new List<Product>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    productList.Add(new Product(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3), reader.GetInt32(4), reader.GetString(5)));
                }
            }
            return productList;

        }

        public List<Product> Mobile_List_View()
        {
            //SqlCommand cmd = new SqlCommand("SELECT id, name, email FROM person", connection);
            /*SqlDataReader reader = DataAccess.GetData("SELECT * FROM Product  WHERE Category='Mobile'");
            List<Product> productList = new List<Product>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    productList.Add(new Product( reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3), reader.GetInt32(4),reader.GetString(5)));
                }
            }
            return productList;
            */
            return service("SELECT * FROM Product  WHERE Category='Mobile'");
        }
        public List<Product> Tablet_View()
        {
            //SqlCommand cmd = new SqlCommand("SELECT id, name, email FROM person", connection);
            /*  SqlDataReader reader = DataAccess.GetData("SELECT * FROM Product  WHERE Category='Tablet'");
              List<Product> productList = new List<Product>();
              if (reader.HasRows)
              {
                  while (reader.Read())
                  {
                      productList.Add(new Product(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3), reader.GetInt32(4), reader.GetString(5)));
                  }
              }
              return productList;
              */

            return service("SELECT * FROM Product  WHERE Category='Tablet'");
        }
        public List<Product> Laptop_View()
        {
            //SqlCommand cmd = new SqlCommand("SELECT id, name, email FROM person", connection);
            /* SqlDataReader reader = DataAccess.GetData("SELECT * FROM Product  WHERE Category='Laptop'");
             List<Product> productList = new List<Product>();
             if (reader.HasRows)
             {
                 while (reader.Read())
                 {
                     productList.Add(new Product(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3), reader.GetInt32(4), reader.GetString(5)));
                 }
             }
             return productList;
             */

            return service("SELECT * FROM Product  WHERE Category='Laptop'");
        }

        public void Edit(Entity.Product product, string mod)
        {
            string query = "UPDATE Product SET Brand= '" + product.Brand + "', Quantity='" + product.Quantity + "',Unitprice='" + product.UnitPrice + "', Details='" + product.Details + "' WHERE Model ='"+mod+"'";
            DataAccess.ExecuteQuery(query);
        }

        public void Delete(Entity.Product product,string mod)
        {
            string query = "DELETE FROM Product Where Model='"+mod+"' ";
            DataAccess.ExecuteQuery(query);
        }

        /*   public void sale_add(Entity.Sale sales)
           {
               string query = "INSERT INTO Sale VALUES('" +sales.Customer_phone+ "', '" +sales.Customer_Name+ "','" +sales.Customer_Email+ "','" +sales.Category+ "', '" +sales.Brand+ "','" +sales.Model+ "', '" +sales.Quantity+ "','" +sales.UnitPrice+ "','" +sales.Total_Bill+ "', '"+sales.Bill_date+"')";
               DataAccess.ExecuteQuery(query);
           }
           */

        public List<Product> Mobile_List_View_Searched(string srch)
        {
            //SqlCommand cmd = new SqlCommand("SELECT id, name, email FROM person", connection);
            /*   SqlDataReader reader = DataAccess.GetData("SELECT * FROM Product  WHERE Category='Mobile' AND (Brand='"+srch+"' OR Model ='"+srch+"' OR Details='"+srch+"')");
               List<Product> productList = new List<Product>();
               if (reader.HasRows)
               {
                   while (reader.Read())
                   {
                       productList.Add(new Product(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3), reader.GetInt32(4), reader.GetString(5)));
                   }
               }
               return productList;
               */

            return service("SELECT * FROM Product  WHERE Category='Mobile' AND (Brand='" + srch + "' OR Model ='" + srch + "' OR Details='" + srch + "')");

        }

        public List<Product> Tablet_View_Searched(string srch)
        {
            //SqlCommand cmd = new SqlCommand("SELECT id, name, email FROM person", connection);
            /*   SqlDataReader reader = DataAccess.GetData("SELECT * FROM Product  WHERE Category='Tablet' AND (Brand='"+srch+"' OR Model ='"+srch+"' OR Details='"+srch+"')");
               List<Product> productList = new List<Product>();
               if (reader.HasRows)
               {
                   while (reader.Read())
                   {
                       productList.Add(new Product(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3), reader.GetInt32(4), reader.GetString(5)));
                   }
               }
               return productList;
               */

            return service("SELECT * FROM Product  WHERE Category='Tablet' AND (Brand='" + srch + "' OR Model ='" + srch + "' OR Details='" + srch + "')");

        }

        public List<Product> Laptop_View_Searched(string srch)
        {
            //SqlCommand cmd = new SqlCommand("SELECT id, name, email FROM person", connection);
            /*  SqlDataReader reader = DataAccess.GetData("SELECT * FROM Product  WHERE Category='Laptop'  AND (Brand='"+srch+"' OR Model ='"+srch+"' OR Details='"+srch+"')");
              List<Product> productList = new List<Product>();
              if (reader.HasRows)
              {
                  while (reader.Read())
                  {
                      productList.Add(new Product(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3), reader.GetInt32(4), reader.GetString(5)));
                  }
              }
              return productList;
              */
            return service("SELECT * FROM Product  WHERE Category='Laptop'  AND (Brand='" + srch + "' OR Model ='" + srch + "' OR Details='" + srch + "')");

        }

        public List<Product> service(string s)
        {
            SqlDataReader reader = DataAccess.GetData(s);
            List<Product> productList = new List<Product>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    productList.Add(new Product(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3), reader.GetInt32(4), reader.GetString(5)));
                }
            }
            return productList;
        }

    }
    }
