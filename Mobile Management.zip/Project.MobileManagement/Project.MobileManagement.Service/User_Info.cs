﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Data;
using System.Data.SqlClient;

namespace Project.MobileManagement.Service
{
    public class User_Info
    {
        public bool User_Info_Check(String name, String type, String id)
        {
            /* string q = "SELECT * FROM User_Table";
             SqlDataReader reader = DataAccess.GetData(q);



             if (reader.HasRows)
             {

                 while (reader.Read())
                 {

                     if (name.Equals(reader.GetString(0)) && type.Equals(reader.GetString(2)) && password.Equals(reader.GetString(1)))
                     {
                         return true;
                     }

                 }
             }


             return false;
             */
            string q = "SELECT * FROM User_Table WHERE Name='"+name+"' AND Type='"+type+ "' AND Password='"+id+"'";
            SqlDataReader reader = DataAccess.GetData(q);
            if (reader.HasRows)
            {

                  return true;

             }
            
            return false;
        }


        public void Add_User_Service_Insert(Entity.User user)
        {

            string query = "INSERT INTO User_Table VALUES('" + user.Name + "', '" + user.User_Type + "','" + user.User_Password + "', '" + user.Email + "','" + user.Phone + "')";
            DataAccess.ExecuteQuery(query);

        }

        public void Add_User_Service_Edit(Entity.User user, string s)
        {

            string query = "UPDATE User_Table SET Name= '" + user.Name + "', Phone='" + user.Phone + "',Type='" + user.User_Type + "', Email='" + user.Email + "' WHERE Password ='"+s+"'";
            DataAccess.ExecuteQuery(query);

        }

        public void Add_User_Service_Delete(User user, string s) {


            string query = "DELETE FROM User_Table Where Password='"+s+"'";
            DataAccess.ExecuteQuery(query);


    }

        public List<User> User_View()
        {
            //SqlCommand cmd = new SqlCommand("SELECT id, name, email FROM person", connection);
            SqlDataReader reader = DataAccess.GetData("SELECT * FROM User_Table");
            List<User> userList = new List<User>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    userList.Add(new User(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4)));
                }
            }
            return userList;

        }
    }
}
