﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Data;
using System.Data.SqlClient;


namespace Project.MobileManagement.Service
{
    public class Sales_Manager
    {
        public void sale_add(Entity.Sale sales)
        {
            string query = "INSERT INTO Sale VALUES('" + sales.Customer_phone + "', '" + sales.Customer_Name + "','" + sales.Customer_Email + "','" + sales.Category + "', '" + sales.Brand + "','" + sales.Model + "', '" + sales.Quantity + "','" + sales.UnitPrice + "','" + sales.Total_Bill + "', '" + sales.Bill_date + "')";
            DataAccess.ExecuteQuery(query);

        }

      /*  public void sales_report(string from,string to)
        {
            string query = "SELECT * FROM Sale WHERE Date like '"+from+"' BETWEEN '"+to+"'";
            SqlDataReader reader = DataAccess.GetData(query);
            reader.Read();

        }
        */

        public List<Sale> sale_report_View(DateTime from, DateTime to)
        {
            //SqlCommand cmd = new SqlCommand("SELECT id, name, email FROM person", connection);
            SqlDataReader reader = DataAccess.GetData("SELECT * FROM Sale WHERE Date  BETWEEN '" + from+"' AND '"+to+"'");
            List<Sale> SaleReportList = new List<Sale>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    SaleReportList.Add(new Sale(reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetString(5), reader.GetInt32(6), reader.GetInt32(7), "Product",reader.GetInt32(8),reader.GetDateTime(9)));
                }
            }
            return SaleReportList;

        }
    }
}
