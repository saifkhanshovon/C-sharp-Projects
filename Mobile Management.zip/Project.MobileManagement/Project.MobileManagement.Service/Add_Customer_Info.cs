﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Data;

namespace Project.MobileManagement.Service
{
    public class Add_Customer_Info
    {
        public void Customer_info(Entity.Customer customer)
        {
            string query = "INSERT INTO Customer VALUES('" + customer.Phone + "', '" + customer.Name + "','" + customer.Email + "', '" + customer.Customer_Address + "','" + customer.Customer_Sex + "')";
            DataAccess.ExecuteQuery(query);
        }
    }
}
