﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Data;
using System.Data.SqlClient;

namespace Project.MobileManagement.Service
{
    public class Add_User_Service
    {

        public void Add_User_Service_Insert(Entity.User user)
        {
           
                string query = "INSERT INTO User_Table VALUES('" + user.Name + "', '" + user.User_Type + "','" + user.User_Password + "', '" + user.Email + "','" + user.Phone + "')";
                DataAccess.ExecuteQuery(query);

        }

    }
}
