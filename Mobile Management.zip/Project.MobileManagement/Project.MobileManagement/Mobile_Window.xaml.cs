﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Service;

namespace Project.MobileManagement
{
    /// <summary>
    /// Interaction logic for Mobile_Window.xaml
    /// </summary>
    public partial class Mobile_Window : Window
    {
        Mobile_List n = new Mobile_List();
        Product p;
        public Mobile_Window()
        {
            InitializeComponent();
        }

        private void close_button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            App.Current.MainWindow = MainWindow.homepage;
            MainWindow.homepage.Show();
        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
            {
                Product p = (Product)e.AddedItems[0];
                model_textbox.Text = p.Model;
                details_textbox.Text = p.Details;
                quantity_textbox.Text = p.Quantity.ToString();
                unit_price_textbox.Text = p.UnitPrice.ToString();
                brand_textbox.Text = p.Brand;
            }
        }

        private void edit_button_Click(object sender, RoutedEventArgs e)
        {
           // Mobile_List n = new Mobile_List();
            Product x = new Product("Mobile", brand_textbox.Text, model_textbox.Text, Convert.ToInt32(quantity_textbox.Text), Convert.ToInt32(unit_price_textbox.Text), details_textbox.Text);
            n.Edit(x, model_textbox.Text);
            this.LoadData();
        }
 

        private void dataGrid_Loadeds(object sender, RoutedEventArgs e)
        {
            
                /*  Product p = (Product)dataGrid.Items[0];
                  quantity_textbox.Text = p.Quantity.ToString();
                  */
                if (dataGrid.Items.Count > 0)
                {
                    p = (Product)dataGrid.Items[0];
                    model_textbox.Text = p.Model;
                    details_textbox.Text = p.Details;
                    quantity_textbox.Text = p.Quantity.ToString();
                    unit_price_textbox.Text = p.UnitPrice.ToString();
                    brand_textbox.Text = p.Brand;
                }
            
        }

        private void LoadData()
        {
           // Mobile_List m = new Mobile_List();
            List<Product> productList = n.Mobile_List_View();
            dataGrid.ItemsSource = productList;
        }

        private void delete_button_Click(object sender, RoutedEventArgs e)
        {
            //Mobile_List n = new Mobile_List();
            Product x = new Product("Mobile", brand_textbox.Text, model_textbox.Text, Convert.ToInt32(quantity_textbox.Text), Convert.ToInt32(unit_price_textbox.Text), details_textbox.Text);
            n.Delete(x,model_textbox.Text);
            this.LoadData();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
           // Product x = new Product("Mobile", brand_textbox.Text, model_textbox.Text, Convert.ToInt32(quantity_textbox.Text), Convert.ToInt32(unit_price_textbox.Text), details_textbox.Text);
           // n.Mobile_List_View_Searched(searchtextbox.Text);
            List<Product> productList = n.Mobile_List_View_Searched(searchtextbox.Text);
            dataGrid.ItemsSource = productList;
        }

    }
}
