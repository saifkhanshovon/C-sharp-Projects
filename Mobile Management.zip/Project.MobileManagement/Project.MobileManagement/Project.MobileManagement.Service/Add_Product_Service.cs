﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Data;
using System.Data.SqlClient;

namespace Project.MobileManagement.Service
{
    public class Add_Product_Service
    {

        public void Add_Product_Service_Insert(Entity.Product product)
        {

            /*string q = "SELECT Quantity FROM Product WHERE Model = 'Galaxy S5' ";
             SqlDataReader reader = DataAccess.GetData(q);
             reader.Read();
             int c = reader.GetInt32(3);
             Console.WriteLine(Convert.ToString(c));
            int z = c + product.Quantity;
             if (c > 0)
             {
                 string k = "UPDATE Product SET Quantity = '" + z + "' WHERE Model = '" + product.Model + "' ";
                 DataAccess.ExecuteQuery(k);
             }

             else
             {

     */

            string query = "INSERT INTO Product VALUES('" + product.Category + "', '" + product.Brand + "','" + product.Model + "', '" + product.Quantity + "','" + product.UnitPrice + "', '" + product.Details + "')";
            DataAccess.ExecuteQuery(query);
            //}

        }

    }
}
