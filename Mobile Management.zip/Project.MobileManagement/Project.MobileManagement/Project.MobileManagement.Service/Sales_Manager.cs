﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Data;


namespace Project.MobileManagement.Service
{
    public class Sales_Manager
    {
        public void sale_add(Entity.Sale sales)
        {
            string query = "INSERT INTO Sale VALUES('" + sales.Customer_phone + "', '" + sales.Customer_Name + "','" + sales.Customer_Email + "','" + sales.Category + "', '" + sales.Brand + "','" + sales.Model + "', '" + sales.Quantity + "','" + sales.UnitPrice + "','" + sales.Total_Bill + "', '" + sales.Bill_date + "')";
            DataAccess.ExecuteQuery(query);

        }
    }
}
