﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Project.MobileManagement.Service;
using Project.MobileManagement.Entity;

namespace Project.MobileManagement
{
    /// <summary>
    /// Interaction logic for Sale_Product_Window.xaml
    /// </summary>
    public partial class Sale_Product_Window : Window
    {
        public Sale_Product_Window()
        {
            InitializeComponent();
        }

        private void close_button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void sale_button_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show(" Products Sold Successfully ");
            Add_Customer_Info objA = new Add_Customer_Info();
            Customer obj = new Customer(phone_textbox.Text,name_textbox.Text,email_textbox.Text,adress_textbox.Text,sex_combobox.Text);
            objA.Customer_info(obj);
            

            //info to Sale
            Sales_Manager sale = new Sales_Manager();
            Sale sale_object = new Sale(phone_textbox.Text, name_textbox.Text, email_textbox.Text,category_combobox.Text,brand_combobox.Text,model_textbox.Text, Convert.ToInt32(quantity_textbox.Text), Convert.ToInt32(unit_price_textbox.Text),"unused", Convert.ToInt32(cost_textbox.Text),dd.DisplayDate);
            sale.sale_add(sale_object);
        }
    }
}
