﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Project.MobileManagement.Service;
using Project.MobileManagement.Entity;

namespace Project.MobileManagement
{
    /// <summary>
    /// Interaction logic for Add_Product_Window.xaml
    /// </summary>
    public partial class Add_Product_Window : Window
    {
        public Add_Product_Window()
        {
            InitializeComponent();
        }

        private void close_button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void add_button_Click(object sender, RoutedEventArgs e)
        {
            Add_Product_Service service_object = new Add_Product_Service();
            // service_object.Add_Product_Service_Insert(category_combobox.Text,brand_combobox.Text,model_textbox.Text,quantity_textbox.Text,unit_price_textbox.Text,details_textbox.Text);
            Product obj1 = new Product(category_combobox.Text, brand_combobox.Text, model_textbox.Text, Convert.ToInt32(quantity_textbox.Text), Convert.ToInt32(unit_price_textbox.Text), details_textbox.Text);
            service_object.Add_Product_Service_Insert(obj1);
            MessageBox.Show(" Product added Successfully ");
        }
    }
}
