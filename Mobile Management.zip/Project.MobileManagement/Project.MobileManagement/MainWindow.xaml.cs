﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Project.MobileManagement.Service;

namespace Project.MobileManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static Home homepage = new Home();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            //Home homepage = new Home();
            App.Current.MainWindow = homepage;
            this.Close();
            homepage.Show();        }

        private void cancel_button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void login_button_Click(object sender, RoutedEventArgs e)
        {
            User_Info User_Info_object = new User_Info();

            bool ans= User_Info_object.User_Info_Check(username_textbox.Text, category_combobox.Text, passwordBox.Text);

            if (ans == true)
            {
                Home homepage = new Home();
                App.Current.MainWindow = homepage;
                this.Close();
                homepage.Show();
            }
            //else
                //invalid_message.Visibility = Visibility.Visible;

        }
    }
}
