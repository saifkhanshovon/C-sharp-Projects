﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Project.MobileManagement.Service;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Data;
using System.Data.SqlClient;


namespace Project.MobileManagement
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Window
    {
        Mobile_Window MobW= new Mobile_Window();
        Laptop_Window LW = new Laptop_Window();
        Tablet_Window TW = new Tablet_Window();
        Edit_User_Window EDW = new Edit_User_Window();
        Sales_Report_Window SRW = new Sales_Report_Window();
        public Home()
        {
            InitializeComponent();
        }

       /* private void Window_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            LoadData();
        }
        */
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Add_Product_Window APW = new Add_Product_Window();
            App.Current.MainWindow = APW;
            APW.Show();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Sale_Product_Window SPW = new Sale_Product_Window();
            App.Current.MainWindow = SPW;
            SPW.Show();
        }

        private void logout_button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow MW = new MainWindow();
            App.Current.MainWindow = MW;
            this.Close();
            MW.Show();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            
            App.Current.MainWindow = LW;
            this.LoadData3();
            LW.Show();
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            App.Current.MainWindow = MobW;
            this.LoadData1();
            MobW.Show();
            this.Close();

        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            App.Current.MainWindow = TW;
            this.LoadData2();
            TW.Show();
        }

        private void help_button_Click(object sender, RoutedEventArgs e)
        {
            Help_Window help = new Help_Window();
            App.Current.MainWindow = help;
            help.Show();
        }

        private void LoadData1()
        {
            Mobile_List mob = new Mobile_List();
            List<Product> productList = mob.Mobile_List_View();
            MobW.dataGrid.ItemsSource = productList;
        }

        private void LoadData2()
        {
            Mobile_List mob = new Mobile_List();
            List<Product> productList = mob.Tablet_View();
            TW.dataGrid.ItemsSource = productList;
        }
        private void LoadData3()
        {
             Mobile_List mob = new Mobile_List();
            List<Product> productList = mob.Laptop_View();
            LW.dataGrid.ItemsSource = productList;
        }

        private void LoadData4()
        {
            User_Info User_Info_object = new User_Info();
            List<User> userList = User_Info_object.User_View();
            EDW.dataGrid.ItemsSource = userList;
        }

        private void LoadData5()
        {
            User_Info User_Info_object = new User_Info();
            List<User> userList = User_Info_object.User_View();
            EDW.dataGrid.ItemsSource = userList;
        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            Add_User_Window ADW = new Add_User_Window();
            App.Current.MainWindow = ADW;
            ADW.Show();
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            //EDW = new Edit_User_Window();
            App.Current.MainWindow = EDW;
            this.LoadData4();
            EDW.Show();
        }

        private void salesR_button_Click(object sender, RoutedEventArgs e)
        {            
            App.Current.MainWindow = SRW;
            //this.LoadData5();
            SRW.Show();
        }
    }
}
