﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Service;

namespace Project.MobileManagement
{
    /// <summary>
    /// Interaction logic for Sales_Report_Window.xaml
    /// </summary>
    public partial class Sales_Report_Window : Window
    {
        Sales_Manager Sales_Manager_object = new Sales_Manager();
        public Sales_Report_Window()
        {
            InitializeComponent();
        }

        private void close_button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void LoadData()
        {
            // Mobile_List m = new Mobile_List();
            List<Sale> SaleList = Sales_Manager_object.sale_report_View(date1.DisplayDate,date2.DisplayDate);
            dataGrid.ItemsSource = SaleList;
        }

        private void edit_button_Click(object sender, RoutedEventArgs e)
        {
            this.LoadData();
        }
    }
}
