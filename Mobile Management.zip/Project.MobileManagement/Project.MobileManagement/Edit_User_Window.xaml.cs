﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Project.MobileManagement.Entity;
using Project.MobileManagement.Service;

namespace Project.MobileManagement
{
    /// <summary>
    /// Interaction logic for Edit_User_Window.xaml
    /// </summary>
    public partial class Edit_User_Window : Window
    {
        public Edit_User_Window()
        {
            InitializeComponent();
        }


        User_Info n = new User_Info();

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
            {
                User p = (User)e.AddedItems[0];
                id_textbox.Text = p.User_Password;
                name_textbox.Text = p.Name;
                email_textbox.Text = p.Email;
                type_textbox.Text = p.User_Type;
                phone_textbox.Text = p.Phone;
            }
        }

        private void dataGrid_Loadeds(object sender, RoutedEventArgs e)
        {

            /*  Product p = (Product)dataGrid.Items[0];
              quantity_textbox.Text = p.Quantity.ToString();
              */
            if (dataGrid.Items.Count > 0)
            {
                User p = (User)dataGrid.Items[0];
                id_textbox.Text = p.User_Password;
                name_textbox.Text = p.Name;
                email_textbox.Text = p.Email;
                type_textbox.Text = p.User_Type;
                phone_textbox.Text = p.Phone;
            }

        }

        private void LoadData()
        {
  
            List<User> userList = n.User_View();
            dataGrid.ItemsSource = userList;
        }

        private void edit_button_Click(object sender, RoutedEventArgs e)
        {
            User x = new User(name_textbox.Text, id_textbox.Text, type_textbox.Text, email_textbox.Text, phone_textbox.Text);
            n.Add_User_Service_Edit(x, id_textbox.Text);
            this.LoadData();
        }

        private void delete_button_Click(object sender, RoutedEventArgs e)
        {

            User x = new User(name_textbox.Text, id_textbox.Text, type_textbox.Text, email_textbox.Text, phone_textbox.Text);
            n.Add_User_Service_Delete(x, id_textbox.Text);
            this.LoadData();

            


    }

        private void close_button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
